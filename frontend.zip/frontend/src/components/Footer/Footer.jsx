
export const Footer =  () => { 
    return  (

<Footer className="footer"> 
    Footer 
</Footer>);
}

