export const MainContent = () => {
    return ( 
    <main className="main"> 
    Content 
    </main>
)}